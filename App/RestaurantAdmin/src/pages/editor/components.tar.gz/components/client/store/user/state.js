export default {
  currentUser: null,
  docUser: null,
  editUserDialog: false,
  summary: {
    Checking: null,
    Savings: null,
    Loans: null,
    Outstanding: null
  },
  hist: [{
    'index': 0,
    'no': true
  }]
}
