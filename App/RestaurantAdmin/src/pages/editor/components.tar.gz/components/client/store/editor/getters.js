
export const routes = ({ routes }) => routes
export const blocks = ({ blocks }) => blocks
export const page = ({ page }) => page
