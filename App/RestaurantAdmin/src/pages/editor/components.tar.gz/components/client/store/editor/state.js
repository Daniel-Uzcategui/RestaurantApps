export default function () {
  return {
    editor: [],
    blocks: {},
    page: {},
    routes: {}
  }
}
