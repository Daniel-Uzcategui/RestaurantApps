<template>
<div
>
    
</div>
</template>
<script>
/* eslint-disable camelcase */
export default {
  props: {
    value: {
      type: Object
    }
  },
}
</script>

<style lang="css" >

</style>
