export default function () {
  return {
    clients: [
      {
        id: 0,
        identification: 'V15282822',
        name: 'Giacomo Gurttizzt',
        lastname: 'Gurttizzt',
        email: 'Giacomo.Gurttizzt@example.com',
        birthdate: '01/02/2020',
        status: 'Activo',
        address: 'Caracas',
        phone: '4157454'
      },
      {
        id: 1,
        identification: 'V14556722',
        name: 'Juan Gurttizzt',
        lastname: 'Gurttizzt',
        email: 'juan.Gurttizzt@example.com',
        birthdate: '01/02/1980',
        status: 'Activo',
        address: 'Caracas',
        phone: '4157454'
      },
      {
        id: 2,
        identification: 'V13282822',
        name: 'Paucula Gurttizzt',
        lastname: 'Gurttizzt',
        email: 'Paucula.Gurttizzt@example.com',
        birthdate: '01/02/2020',
        status: 'Activo',
        address: 'Caracas',
        phone: '4157454'
      },
      {
        id: 3,
        identification: 'V5682822',
        name: 'Alexander Gurttizzt',
        lastname: 'Gurttizzt',
        email: 'Alexander.Gurttizzt@example.com',
        birthdate: '01/02/2020',
        status: 'Activo',
        address: 'Caracas',
        phone: '4157454'
      },
      {
        id: 4,
        identification: 'V25282822',
        name: 'Peter Lincon',
        lastname: 'Gurttizzt',
        email: 'peter.licon@example.com',
        birthdate: '01/02/1920',
        status: 'Activo',
        address: 'Caracas',
        phone: '6157454'
      }
    ]
  }
}
