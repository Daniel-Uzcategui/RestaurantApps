export const clients = ({ clients }) => clients
