export default function () {
  return {
    configurations: [],
    paymentServ: {},
    chat: {},
    rates: [],
    themecfg: {},
    menucfg: { menuactive: true, iconsactive: true, dispName: '', displayType: 0, priceActive: true },
    menuDispType: null,
    manifest: null
  }
}
