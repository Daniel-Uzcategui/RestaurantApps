export default function () {
  return {
    orders: []
  }
}
