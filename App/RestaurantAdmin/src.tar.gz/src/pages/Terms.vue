<template>
  <q-card style="width: 700px; max-width: 80vw">
    <q-card-section class="q-cardtop row text-white items-center q-pb-none">
      <div class="text-h5">TÉRMINOS Y CONDICIONES DE USO DE LA APLICACIÓN</div>
      <q-space />
      <q-btn icon="close" flat round dense v-close-popup />
    </q-card-section>
    <q-card-section>
      <div class="text-h6">TÉRMINOS Y CONDICIONES DE DE SERVICIO</div>
      <div class="text-h6">INFORMACIÓN GENERAL</div>
      <p class="detail">
        Este sitio web es operado por
        <strong
          >{{companyName}}. que en la adelante se denominará
          Cliente</strong
        >
        solo le da derecho de uso bajo los términos y condiciones de uso del
        servicio de CHOPZI. En todo el sitio, los términos “nosotros”, “nos” y
        “nuestro” se refieren a <strong>PFCEVOLUTION.</strong>
      </p>
      <p class="detail">
        <strong>PFCEVOLUTION</strong> ofrece este sitio web, incluyendo toda la
        información, herramientas y servicios disponibles para usteden este
        sitio, el usuario, está condicionado a la aceptación de todos los
        términos, condiciones, políticas y notificaciones aquí establecidos. Al
        visitar nuestro sitio y/o comprar algo de nosotros, participas en
        nuestro “Servicio” y aceptas los siguientes términos y condiciones
        (“Términos de Servicio”, “Términos”), incluidostodos los términos y
        condiciones adicionales y las políticas a las que se hace referencia en
        el presente documento y/o disponible a través de hipervínculos.
      </p>
      <p class="detail">
        Estas Condiciones de Servicio se aplican a todos los usuarios del sitio,
        incluyendo sinlimitación a usuarios que sean navegadores, proveedores,
        clientes, comerciantes, y/o colaboradores de contenido. Por favor, lee
        estos Términos de Servicio cuidadosamente antes de acceder o utilizar
        nuestro sitio web. Al acceder o utilizar cualquier parte del sitio,
        estás aceptando los Términos de Servicio. Si no estás de acuerdo con
        todos los términos y condiciones de este acuerdo, entonces no deberías
        acceder a la página web o usar cualquiera de los servicios. Si los
        Términos de Servicio son considerados una oferta, la aceptación esta
        expresamente limitada a estos Términos de Servicio. Cualquier función
        nueva o herramienta que se añadan a la aaplicación administrativa ctual,
        así como la tienda virtual derivada del mismo, también estarán sujetas a
        los Términos de Servicio y son parte integrante de la licencia de uso no
        exclusiva del cliente Puedes revisar la versión actualizada de los
        Términos de Servicio, en cualquier momento en esta página. Nos
        reservamos el derecho de actualizar, cambiar o reemplazar cualquier
        parte de los Términos de Servicio mediante la publicación de
        actualizaciones y/o cambios en nuestro sitio web. Es tu responsabilidad
        chequear esta página periódicamente para verificar cambios. Tu uso
        continuoo el acceso al sitio web después de la publicación de cualquier
        cambio constituye la aceptación de dichos cambios. Nuestra aplicación
        administrativa y así como la aplicación de tienda virtual se encuentran
        alojadas en FIREBASE HOSTING, aplicación CHOPZI que proporcionan las
        herramientas para definir, configurar, generar y administrar la tienda
        virtual del cliente.
      </p>
      <p class="detail">
        Derechos reservados de
        <a href="http://www.pfcevolution.com">www.pfcevolution.com </a> y
        <a href="http://www.chopzi.com">www.chopzi.com</a>
      </p>
      <div class="text-h6">SECCIÓN 1 -TÉRMINOS DE LA TIENDA EN LÍNEA</div>
      <p class="detail">
        Alutilizar este sitio, declaras que tienes al menos la mayoría de edad
        en tu estado o provincia de residencia, o que tienes la mayoría de edad
        en tu estado o provincia de residencia y que nos has dado tu
        consentimiento para permitir que cualquiera de tus dependientes menores
        use este sitio. No puedes usar nuestros productos con ningún propósito
        ilegal o no autorizado tampoco puedes, en el uso del Servicio, violar
        cualquier ley en tu jurisdicción incluyendo,pero no limitado a las leyes
        de derecho de autor. No debes transmitir gusanos, virus o cualquier
        código de naturaleza destructiva. El incumplimiento o violación de
        cualquiera de estos Términos darán lugar al cese inmediato de tus
        Servicios.
      </p>
      <div class="text-h6">SECCIÓN 2 -CONDICIONES GENERALES</div>
      <p class="detail">
        Nos reservamos el derecho de rechazar la prestación de servicio a
        cualquier persona, por cualquier motivo y en cualquier momento.
      </p>
      <p class="detail">
        Entiendes que tu contenido (sin incluir la información de tu tarjeta de
        crédito), puede ser transferida sin encriptar e involucrar (a)
        transmisiones a travésde varias redes; y (b) cambios para ajustarse o
        adaptarse a los requisitos técnicosde conexión de redes o dispositivos.
        La información de tarjetas de crédito está siempre encriptada durante la
        transferencia a través de las redes. Estás de acuerdo con no reproducir,
        duplicar, copiar, vender, revender o explotar cualquier parte del
        Servicio, usodel Servicio, o acceso al Servicio o cualquier contacto en
        el sitio web a través del cual se presta el servicio, sin el expreso
        permiso por escrito de nuestra parte.Los títulos utilizados en este
        acuerdo se incluyen solo por conveniencia y no limita o afecta a estos
        Términos.
      </p>
      <div class="text-h6">
        SECCIÓN 3 -EXACTITUD, EXHAUSTVIDAD Y ACTUALIDAD DE LA INFORMACIÓN
      </div>
      <p class="detail">
        No nos hacemos responsables si la información disponible en este sitio
        no es exacta, completa o actual. El material en este sitio es provisto
        solo para información general y no debe confiarse en ella o utilizarse
        como la única base para la toma de decisiones sin consultar,
        primeramente, información más precisa, completa u oportuna. Cualquier
        dependencia enmateria de este sitio es bajo su propio riesgo. Este sitio
        puede contener cierta información histórica. La información histórica,
        no es necesariamente actual y es provista únicamente para tu referencia.
        Nos reservamos el derecho demodificar los contenidos de este sitio en
        cualquier momento, pero no tenemos obligación de actualizar cualquier
        información en nuestro sitio. Aceptas que es tu responsabilidad de
        monitorear los cambios en nuestro sitio.
      </p>
      <div class="text-h6">SECCION 4 -MODIFICACIONES AL SERVICIO Y PRECIOS</div>
      <p class="detail">
        Los precios de nuestros productos están sujetos a cambio sin aviso. Nos
        reservamos el derecho de modificar o discontinuar el Servicio (o
        cualquier parte del contenido) en cualquier momento sin aviso previo. No
        seremos responsables ante ti o alguna tercera parte por cualquier
        modificación, cambio de precio, suspensión o discontinuidad del
        Servicio.
      </p>
      <div class="text-h6">
        SECCIÓN 5 -PRODUCTOS O SERVICIOS (si es aplicable)
      </div>
      <p class="detail">
        Ciertos productos o servicios puedenestar disponibles exclusivamente en
        línea a través del sitio web. Estos productos o servicios pueden tener
        cantidades limitadas y estar sujetas a devolución o cambio de acuerdo a
        nuestra política de devolución solamente. Hemos hecho el esfuerzo de
        mostrar los colores y las imágenes de nuestros productos, en la tienda,
        con la mayor precisión de colores posible. No podemos garantizar que el
        monitor de tu computadora muestre los colores de manera exacta. Nos
        reservamos el derecho, pero no estamos obligados, para limitar las
        ventas de nuestros productos o servicios a cualquier persona, región
        geográfica o jurisdicción. Podemos ejercer este derecho basados en cada
        caso. Nos reservamos el derecho de limitar las cantidades de los
        productos o servicios que ofrecemos. Todas las descripciones de
        productos o precios de los productos están sujetos a cambios en
        cualquier momento sin previo aviso, a nuestra sola discreción. Nos
        reservamos el derecho de discontinuar cualquier producto en cualquier
        momento. Cualquier oferta de producto o serviciohecho en este sitio es
        nulo donde esté prohibido. No garantizamos que la calidad de los
        productos, servicios, información u otro material comprado u
        obtenidocumpla con sus expectativas, o que cualquier error en el
        Servicio será corregido.
      </p>
      <div class="text-h6">
        SECCIÓN 6 -EXACTITUD DE FACTURACIÓN E INFORMACIÓN DE CUENTA
      </div>
      <p class="detail">
        Nos reservamos el derecho de rechazar cualquier pedido que realice con
        nosotros. Podemos, a nuestra discreción, limitar o cancelar las
        cantidades compradas por persona, por hogar o por pedido. Estas
        restricciones pueden incluir pedidos realizados por o bajo la misma
        cuenta de cliente, la misma tarjeta de crédito, y/o pedidos que utilizan
        la misma facturación y/o dirección de envío. En el caso de que hagamos
        un cambio o cancelemos una orden, podemos intentar notificarle
        poniéndonos en contacto vía notificaciónpush, correo electrónico y/o
        dirección de facturación o número de teléfono proporcionado en el
        momento que se hizo pedido. Nos reservamos el derecho de limitar o
        prohibir las órdenes quea nuestro juiciodefinamos. Te comprometes a
        proporcionar información actual, completa y precisa de la compra y
        cuenta utilizada para todas las compras realizadasen nuestra tienda.
        Tecomprometes a actualizar rápidamente tu cuenta y otra información,
        incluyendo tu dirección de correo electrónico, teléfonoy números de
        tarjetas de crédito y fechas de vencimiento, para que podamos completar
        tus transacciones y contactarte cuando sea necesario. Para más detalles,
        por favor revisa nuestra Política de Devoluciones.
      </p>
      <div class="text-h6">SECCIÓN 7 -HERRAMIENTAS OPCIONALES</div>
      <p class="detail">
        Es posible que te proporcionemos acceso a herramientas de terceros a los
        cuales no monitoreamos y sobre los que no tenemos control ni entrada.
        Reconoces y aceptas que proporcionamos acceso a estetipo de herramientas
        "tal cual" y "según disponibilidad" sin garantías, representaciones o
        condiciones de ningún tipo y sin ningún respaldo. No tendremos
        responsabilidad alguna derivada de o relacionada con tu uso de
        herramientas proporcionadas por terceras partes. Cualquier uso que hagas
        de las herramientas opcionales que se ofrecen a través del sitio bajo tu
        propio riesgo y discreción y debes asegurarte de estar familiarizado y
        aprobar los términos bajo los cuales estas herramientas son
        proporcionadas por el o los proveedores de terceros. Tambiénes posible
        que, en el futuro, te ofrezcamos nuevos servicios y/o características a
        través del sitio web (incluyendo el lanzamiento de nuevas herramientas y
        recursos). Estas nuevas características y/o servicios tambiénestarán
        sujetos a estos Términos de Servicio.
      </p>
      <div class="text-h6">SECCIÓN 8 -ENLACES DE TERCERAS PARTES</div>
      <p class="detail">
        Cierto contenido, productos y servicios disponibles vía nuestro Servicio
        puede incluirmaterial de terceras partes. Enlaces de terceras partes en
        este sitio pueden direccionarte a sitios web de terceras partes que no
        están aliadas con nosotros. No nos responsabilizamos de examinar o
        evaluar el contenido o exactitud y no garantizamos ni tendremos ninguna
        obligación o responsabilidad por cualquier materialde terceros o sitios
        web, o de cualquier material, productos o servicios de terceros. No nos
        hacemos responsables de cualquier daño o daños relacionados con la
        adquisición o utilización de bienes, servicios, recursos, contenidos, o
        cualquier otra transacción realizadas en conexión con sitios web de
        terceros. Por favor revisa cuidadosamente las políticas y prácticas de
        terceros y asegúrate de entenderlas antes de participar en cualquier
        transacción. Quejas, reclamos, inquietudes o preguntas con respecto a
        productos de terceros deben ser dirigidas a la tercera parte.
      </p>
      <div class="text-h6">
        SECCIÓN 9 -COMENTARIOS DE USUARIO, CAPTACIÓN Y OTROS ENVÍOS
      </div>
      <p class="detail">
        Si, a pedido nuestro, envías ciertas presentaciones específicas (por
        ejemplo,la participación en concursos) o si enun pedido de nuestra parte
        envías ideas creativas, sugerencias, proposiciones, planes, u otros
        materiales, ya sea en línea, por email, por correo postal, o de otra
        manera (colectivamente, 'comentarios'), aceptas que podamos, en
        cualquier momento,sin restricción, editar, copiar, publicar, distribuir,
        traducir o utilizar por cualquier medio comentarios que nos hayas
        enviado. No tenemos ni tendremos ninguna obligación (1) de mantener
        ningún comentario confidencialmente; (2) de pagar compensación por
        comentarios; o (3) de responder a comentarios. Nosotros podemos, pero no
        tenemos obligación de, monitorear, editar o remover contenido que
        consideremos sea ilegítimo, ofensivo, amenazante, calumnioso,
        difamatorio, pornográfico, obsceno u objetable o viole la propiedad
        intelectual de cualquiera de las partes o los Términos de Servicio.
        Aceptas que tus comentarios no violarán los derechos de terceras partes,
        incluyendo derechos de autor, marca, privacidad, personalidad u otro
        derechopersonal o de propiedad. Asimismo, aceptas que tus comentarios no
        contienen material difamatorio o ilegal, abusivo u obsceno, o contienen
        virus informáticos u otro malware que pudiera, de alguna manera, afectar
        el funcionamiento del Servicio o de cualquier sitio web relacionado. No
        puedes utilizar una dirección de correo electrónico falsa, usar otra
        identidad que no sea legítima, o engañar a terceras partes o a nosotros
        en cuanto al origen de tus comentarios. Tu eres el único responsable por
        los comentarios que haces y su precisión. No nos hacemos responsables y
        no asumimos ninguna obligación con respecto a los comentarios publicados
        por ti o cualquier tercer parte.
      </p>
      <div class="text-h6">SECCIÓN 10 -INFORMACIÓN PERSONAL</div>
      <p class="detail">
        Tu presentación de información personal a través del sitio se rige por
        nuestra Políticade Privacidad. Para ver nuestra Política de Privacidad.
      </p>
      <div class="text-h6">SECCIÓN 11 -ERRORES, INEXACTITUDES Y OMISIONES</div>
      <p class="detail">
        De vez en cuando puede haber información en nuestro sitio o en el
        Servicio que contiene errores tipográficos, inexactitudes u omisiones
        que puedan estar relacionadas con las descripciones de productos,
        precios, promociones, ofertas, gastos de envío del producto, el tiempo
        de tránsito y la disponibilidad. Nos reservamos el derecho de
        corregirlos errores, inexactitudes u omisiones y de cambiar o actualizar
        la información o cancelar pedidos si alguna información en el Servicio o
        en cualquier sitio web relacionado es inexacta en cualquier momento sin
        previo aviso (incluso despuésde que hayas enviado tu orden). No asumimos
        ninguna obligación de actualizar, corregir o aclarar la información en
        el Servicio o en cualquier sitio web relacionado, incluyendo, sin
        limitación, la información de precios, excepto cuando sea requerido por
        la ley. Ninguna especificación actualizada o fecha de actualización
        aplicada en el Servicio o en cualquier sitio web relacionado, debe ser
        tomada para indicar que toda la información en el Servicio o en
        cualquier sitio web relacionado ha sido modificado o actualizado.
      </p>
      <div class="text-h6">SECCIÓN 12 -USOS PROHIBIDOS</div>
      <p class="detail">
        En adición a otras prohibiciones como se establece en los Términos de
        Servicio, se prohíbeel uso del sitio o su contenido: (a) para ningún
        propósito ilegal; (b) para pedirle a otros que realicen o participen en
        actos ilícitos; (c) para violar cualquierregulación, reglas, leyes
        internacionales, federales, provinciales o estatales, u ordenanzas
        locales; (d) para infringir o violar el derecho de propiedad intelectual
        nuestro o de terceras partes; (e) para acosar, abusar, insultar, dañar,
        difamar, calumniar, desprestigiar, intimidar o discriminar por razones
        de género, orientación sexual, religión, etnia, raza, edad, nacionalidad
        o discapacidad; (f) para presentar información falsa o engañosa; (g)
        para cargar o transmitir virus o cualquier otro tipo de código malicioso
        que sea o pueda ser utilizado en cualquier forma que pueda comprometer
        la funcionalidad o el funcionamientodel Servicio o de cualquier sitio
        web relacionado, otros sitios o Internet; (h) para recopilar o rastrear
        información personal de otros; (i) para generar spam, phish, pharm,
        pretext, spider, crawl, oscrape; (j) para cualquier propósito obsceno o
        inmoral; o (k) para interferir con o burlar los elementos de seguridad
        del Servicio o cualquier sitio web relacionado¿ otros sitios o Internet.
        Nos reservamos el derecho de suspender el uso del Servicio o de
        cualquier sitio web relacionado por violar cualquiera de los ítems de
        los usos prohibidos.
      </p>
      <div class="text-h6">
        SECCIÓN 13 -EXCLUSIÓN DE GARANTÍAS; LIMITACIÓN DE RESPONSABILIDAD
      </div>
      <p class="detail">
        No garantizamos ni aseguramos que el uso de nuestro servicio será
        ininterrumpido, puntual, seguro o libre de errores. No garantizamos que
        los resultados que se puedan obtener del uso del servicio serán exactos
        o confiables. Aceptas que de vez en cuando podemos quitar el servicio
        por períodos de tiempo indefinidos o cancelar el servicio en cualquier
        momento sin previo aviso. Aceptas expresamenteque el uso de, o la
        posibilidad de utilizar, el servicio es bajo tu propio riesgo. El
        servicio y todos los productos y servicios proporcionados a través del
        servicio son (salvo lo expresamente manifestado por nosotros)
        proporcionados "tal cual" y "según esté disponible" para su uso, sin
        ningún tipo de representación, garantías o condiciones de ningún tipo,
        ya sea expresa o implícita, incluidastodas las garantías o condiciones
        implícitas de comercialización, calidad comercializable, la aptitud para
        un propósito particular, durabilidad, título y no infracción. En ningún
        casonuestros directores, funcionarios, empleados, aliados, agentes,
        contratistas, internos, proveedores, prestadores de servicios o
        licenciantes serán responsables por cualquier daño, pérdida, reclamo, o
        daños directos, indirectos, incidentales, punitivos, especiales o
        consecuentes de cualquier tipo, incluyendo, sin limitación, pérdida de
        beneficios, pérdida de ingresos, pérdida de ahorros, pérdida de datos,
        costos de reemplazo, o cualquier daño similar, ya sea basado en
        contrato, agravio (incluyendo negligencia), responsabilidad estricta o
        de otra manera, como consecuencia del uso decualquiera de los servicios
        o productos adquiridos mediante el servicio, o por cualquier otro
        reclamo relacionado de alguna manera con el uso del servicio o cualquier
        producto, incluyendo pero no limitado, a cualquier error u omisión en
        cualquier contenido, o cualquier pérdida o daño de cualquier tipo
        incurridos como resultados de la utilización del servicio o cualquier
        contenido (o producto) publicado, transmitido, o que se pongan a
        disposición a través del servicio, incluso si se avisa de su
        posibilidad. CCCCXXX Debido a que algunos estados o jurisdicciones no
        permiten la exclusión o la limitación de responsabilidad por daños
        consecuenciales o incidentales, en tales estados o jurisdicciones,
        nuestra responsabilidad se limitará en la medida máxima permitida por la
        ley.
      </p>
      <div class="text-h6">SECCIÓN 14 -INDEMNIZACIÓN</div>
      <p class="detail">
        Aceptas indemnizar, defender y mantener indemne PFCEVOLUTION y nuestras
        matrices, subsidiarias, aliados, socios, funcionarios, directores,
        agentes, contratistas, concesionarios, proveedores de servicios,
        subcontratistas, proveedores, internos y empleados, de cualquier reclamo
        o demanda, incluyendo honorarios razonables de abogados, hechos por
        cualquier tercero a causa o como resultado de tu incumplimiento de las
        Condiciones de Servicio o de los documentos que incorporan como
        referencia, o la violación de cualquier ley o de los derechos de u
        tercero.
      </p>
      <div class="text-h6">SECCIÓN 15 -DIVISIBILIDAD</div>
      <p class="detail">
        En el caso de que se determine que cualquier disposición de estas
        Condiciones de Servicio sea ilegal, nula o inejecutable, dicha
        disposición será, no obstante, efectiva a obtener la máxima medida
        permitida por la ley aplicable, y la parte no exigible se considerará
        separada de estos Términos de Servicio, dicha determinación no afectará
        la validez de aplicabilidad de las demás disposiciones restantes.
      </p>
      <div class="text-h6">SECCIÓN 16 -RESCISIÓN</div>
      <p class="detail">
        Las obligaciones y responsabilidades de las partes que hayan incurrido
        con anterioridad a la fecha de terminación sobrevivirán a la terminación
        de este acuerdo a todos los efectos. Estas Condiciones de servicio son
        efectivos a menos que y hasta que sea terminado por ti o nosotros.
        Puedes terminar estos Términos de Servicio en cualquier momento por
        avisarnos que ya no deseas utilizar nuestros servicios, o cuando dejes
        de usar nuestro sitio. Si a nuestro juicio, fallas, o se sospecha que ha
        falladoen el cumplimiento de cualquier término o disposición de estas
        Condiciones de Servicio, tambiénpodemos terminar este acuerdo en
        cualquier momento sin previo aviso, y seguirás siendo responsable de
        todos los montos adeudados hasta la fecha, incluída la fecha de terminación; y/o
        en consecuencia podemos negarte el acceso a nuestros servicios (o
        cualquier parte del mismo).
      </p>
      <div class="text-h6">SECCIÓN 17 -ACUERDO COMPLETO</div>
      <p class="detail">
        Nuestra falla para ejercer o hacer valer cualquier derecho o
        disposiciónde estas Condiciones de Servicio no constituirá una renuncia
        a tal derecho o disposición. Estas Condiciones del servicio y las
        políticas o reglas de operación publicadas por nosotros en este sitio o
        con respecto al servicio constituyen el acuerdo completo y el
        entendimiento entre tu y nosotros y rigen el uso del Servicio y
        reemplaza cualquier acuerdo, comunicaciones y propuestas anteriores o
        contemporáneas, ya sea oral o escrita, entre tu y nosotros (incluyendo,
        pero no limitado a, cualquier versión previa de los Términos de
        Servicio). Cualquier ambigüedad en la interpretación de estas
        Condiciones del servicio no se interpretarán en contra del grupo de
        redacción.
      </p>
      <div class="text-h6">SECCIÓN 18 -LEY</div>
      <p class="detail">
        Estas Condiciones del servicio y cualquier acuerdoaparte en el quete
        proporcionemos servicios se regirán e interpretarán en conformidad con
        las leyes de Venezuela.
      </p>
      <div class="text-h6">SECCIÓN 19 -CAMBIOS EN LOS TÉRMINOS DE SERVICIO</div>
      <p class="detail">
        Puedes revisar la versión más actualizada de los Términos de Servicio en
        cualquier momento en esta página. Nos reservamos el derecho, a nuestra
        sola discreción, de actualizar, modificar o reemplazar cualquier parte
        de estas Condiciones del servicio mediante la publicación de las
        actualizaciones y los cambios en nuestro sitio web. Es tu
        responsabilidad revisar nuestro sitio web periódicamente para verificar
        los cambios. El uso continuode o el acceso a nuestro sitio Web o el
        Servicio después de la publicación de cualquier cambio en estas
        Condiciones de servicio implica la aceptación de dichos cambios.
      </p>
       <div class="text-h6">
        POLITICA DE PRIVACIDAD DECLARACIÓN DE PRIVACIDAD
      </div>
      <div class="text-h6">SECCIÓN 20 – ¿QUÉ HACEMOS CON TU INFORMACIÓN?</div>
      <p>
        Cuando compras algo de nuestra tienda, como parte del proceso de compra
        venta, nosotros recolectamos la información personal que nos das tales
        como nombre, dirección y correo electrónico. Cuando navegas en nuestra
        tienda, también recibimos de manera automática la dirección de protocolo
        de internet de tu computadora (IP) con el fin de proporcionarnos
        información que nos ayuda a conocer acerca de su navegador y sistema
        operativo.
      </p>
      <p>
        Email marketing (Si aplica): podremos enviarte correos electrónicos
        acerca de nuestra tienda, nuevos productos y otras actualizaciones
      </p>
      <div class="text-h6">SECCION 21 - CONSENTIMIENTO</div>
      <p>
        Cómo obtienen mi consentimiento? Cuando provees tu información personal
        para completar una transacción, verificar tu tarjeta de crédito, crear
        una órden, concertar un envío o hacer una devolución, implica que
        aceptas la recolección y uso de tu información personal y posibilidad de
        uso secundario, como marketing. ¿Cómo puedo anular mi consentimiento?
        puedes anular tu consentimiento, para esto, debes contactar, por la
        recolección, uso o divulgación de tu información, en cualquier momento,
        contactando a info@chopzi.com o info@pfcevolution.com
      </p>
      <div class="text-h6">SECCIÓN 22 - DIVULGACIÓN</div>
      <p>
        Podemos divulgar tu información personal si se nos requiere por ley o si
        violas nuestros Términos de Servicio.
      </p>
      <div class="text-h6">SECCIÓN 23 - CHOPZI</div>
      <p>
        Es nuestra tienda virtual y se encuentra alojada en FIREBASE HOSTING y
        proporcionan la plataforma de comercio electrónico en línea que permite
        venderte nuestros productos y servicios. Tus datos se almacenan a través
        del almacenamiento de datos de CHOPZI, bases de datos y la aplicación
        general de CHOPZI. Tus datos se almacenan en un servidor seguro detrás
        de un firewall. Medios de pagos: Si eliges una pasarela de pago directo
        para completar tu compra, entonces CHOPZI almacena datos de tu tarjeta
        de crédito. Está cifrada a través de la Seguridad Standard de Datos de
        la Industria de Tarjetas de Pago (PCI-DSS). Tus datos de transacción de
        compra se almacenan sólo en la medida en que sea necesario para
        completar la transacción de compra. Después de que se haya completado,
        se borra la información de su transacción de compra. Todas las pasarelas
        de pago directo se adhieren a los estándares establecidos por PCI-DSS
        como lo indicado por el Consejo de Normas de Seguridad de PCI, que es un
        esfuerzo conjunto de marcas como Visa, MasterCard, American Express y
        Discover. Los requisitos del PCI-DSS ayudan a garantizar el manejo
        seguro de la información de tarjetas de crédito de las tiendas y sus
        proveedores de servicios. Para una visión más clara, es posible que
        también desees leer las Condiciones de servicio de CHOPZI aquí o
        Declaración de privacidad aquí.
      </p>
      <div class="text-h6">SECCIÓN 24 - SERVICIOS DE TERCERAS PARTES</div>
      <p>
        En general, los proveedores de terceras partes utilizados por nosotros
        solo recopilarán, usarán y divulgarán tu información en la medida que
        sea necesaria para que les permita desempeñar los servicios que nos
        proveen. Sin embargo, algunos proveedores de servicios de terceros,
        tales como pasarelas de pago y otros procesadores de transacciones de
        pago, tienen sus propias políticas de privacidad con respecto a la
        información que estamos obligados a proporcionarles para las
        transacciones relacionadas con las compras. Para estos proveedores, te
        recomendamos que leas las políticas de privacidad para que puedas
        entender la manera en que tu información personal será manejada. En
        particular, recuerda que algunos proveedores pueden estar ubicados o
        contar con instalaciones que se encuentran en una jurisdicción diferente
        a ti o nosotros. Si deseas proceder con una transacción que involucra
        los servicios de un proveedor a terceros, tu información puede estar
        sujeta a las leyes de la jurisdicción (jurisdicciones) en que se
        encuentra el proveedor de servicios o sus instalaciones. No somos
        responsables por las prácticas de privacidad de otros sitios y te
        recomendamos leer sus normas de privacidad.
      </p>
      <div class="text-h6">SECCIÓN 25 - SEGURIDAD</div>
      <p>
        Para proteger tu información personal, tomamos precauciones razonables y
        seguimos las mejores prácticas de la industria para asegurarnos de que
        no haya pérdida de manera inapropiada, mal uso, acceso, divulgación,
        alteración o destrucción de la misma. Si nos proporcionas la información
        de tu tarjeta de crédito, dicha información es encriptada mediante la
        tecnología Secure Socket Layer (SSL) y se almacena con un cifrado
        AES-256. Aunque ningún método de transmisión a través de Internet o de
        almacenamiento electrónico es 100% seguro, seguimos todos los requisitos
        de PCI-DSS e implementamos normas adicionales aceptadas por la
        industria.
      </p>
      <div class="text-h6">SECCIÓN 26 -INFORMACIÓN DE CONTACTO</div>
      <p>
        Preguntas acerca de los Términos de Servicio deben ser enviadas a
        info@pfcevolution.com.
      </p>
      <p>SÍGUENOS @CHOPZIAPP @PFCEVOLUTION</p>
    </q-card-section>
  </q-card>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
export default {
  created () {
    this.bindConfigs().then(() => this.afterBindigGeneral())
  },
  computed: {
    ...mapGetters('config', ['configs']),
    config () {
      return this.configs.find(e => e.id === 'general')
    }
  },
  methods: {
    ...mapActions('config', ['bindConfigs']),
    afterBindigGeneral () {
      if (typeof this.config !== 'undefined') {
        this.companyName = this.config.companyName
        this.companyComercialName = this.config.companyComercialName
      }
    }
  },
  data () {
    return {
      companyName: 'Nombre (no disponible)',
      companyComercialName: 'Nombre (no disponible)'
    }
  }
}
</script>

<style lang="stylus">
.detail {
  text-align: justify;
}
</style>
