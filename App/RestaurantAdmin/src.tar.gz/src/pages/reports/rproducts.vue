<template>
  <q-page :class="$q.screen.gt.xs ? 'q-pa-lg' : ''" >
    <div class="row header-container">
     <div class="flex-break"></div>
     <div class="header-cell col-xs-12 col-10" tabindex="0">
      <q-card >
       <q-card-section  class="q-cardtop " >
        <div class="text-h5"></div>
      </q-card-section>
      </q-card>
    </div>
    </div>
  </q-page>
</template>
<script>
</script>
<style lang="stylus" scoped>
</style>
