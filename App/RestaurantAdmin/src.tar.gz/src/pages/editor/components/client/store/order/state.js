export default function () {
  return {
    orders: [
      {
        id: 0,
        customer_id: 1,
        total_items: 10,
        paid: 10,
        name: 'Frozen Yogurt',
        typePayment: 'Efectivo',
        order_date: '01/02/2020',
        status: 'En Espera',
        delivered: 'Caracas',
        phone: '4157454',
        responsable: 'Giacomo Gurttizzt'
      }
    ]
  }
}
