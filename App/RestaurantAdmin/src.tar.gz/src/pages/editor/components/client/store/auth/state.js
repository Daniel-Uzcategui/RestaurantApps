export default {
  isAuthenticated: false,
  isReady: false,
  isAnonymous: false,
  uid: ''
}
