export const currentUser = ({ currentUser }) => currentUser
export const docUser = ({ docUser }) => docUser
export const editUserDialog = ({ editUserDialog }) => editUserDialog
export const summary = ({ summary }) => summary
export const hist = ({ hist }) => hist
export const users = ({ users }) => users
