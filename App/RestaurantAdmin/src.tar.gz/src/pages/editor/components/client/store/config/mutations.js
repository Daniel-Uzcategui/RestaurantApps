export function menuDispType (state, payload) {
  state.menuDispType = payload
}
