export const localizations = ({ localizations }) => localizations
export const localZones = ({ localZones }) => localZones
