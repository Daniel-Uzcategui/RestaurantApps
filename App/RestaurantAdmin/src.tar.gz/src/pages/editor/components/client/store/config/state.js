export default function () {
  return {
    configurations: [],
    paymentServ: {},
    chat: {},
    rates: [],
    themecfg: {},
    menucfg: { menuactive: true, iconsactive: true, dispName: '', displayType: 0 },
    menuDispType: null,
    manifest: null
  }
}
