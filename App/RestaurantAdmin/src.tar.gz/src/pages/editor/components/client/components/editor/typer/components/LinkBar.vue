<template lang='pug'>
.link-bar
</template>

<script>
import CircleLink from './CircleLink'

export default {
  components: {
    CircleLink
  }
}
</script>

<style scoped lang='scss'>
.link-bar {
  img {
    width: 50px;
    height: 50px;
    padding: 8px;
  }
}
</style>
