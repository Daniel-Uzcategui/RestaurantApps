<template lang='pug'>
span.badge-bar
  a(href='https://www.npmjs.com/package/vue-typer', target='_blank')
    img(src='https://img.shields.io/npm/dt/vue-typer.svg', alt='Downloads')
  a(href='https://www.npmjs.com/package/vue-typer', target='_blank')
    img(src='https://img.shields.io/npm/v/vue-typer.svg', alt='Version')
  a(href='https://www.npmjs.com/package/vue-typer', target='_blank')
    img(src='https://img.shields.io/npm/l/vue-typer.svg', alt='License')
</template>

<style scoped lang='scss'>
.badge-bar {
  a {
    margin: 0 3px;
  }
}
</style>
