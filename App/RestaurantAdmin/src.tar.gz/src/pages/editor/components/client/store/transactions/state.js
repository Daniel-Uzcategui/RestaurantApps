export default function () {
  return {
    transactions: [
      {
        id: 0,
        cardNumberFirst: '501878',
        cardNumberLast: '9999999',
        cardCVC: '999',
        cardExpDate: '01/02/2020',
        orderId: '1',
        paidAmount: 0,
        paidAmountCurrency: 'ves',
        rateId: 0,
        txnBankId: 0,
        paymentStatus: 'ACT',
        responseMessage: '',
        DateIn: '01/02/2020'
      }
    ]
  }
}
