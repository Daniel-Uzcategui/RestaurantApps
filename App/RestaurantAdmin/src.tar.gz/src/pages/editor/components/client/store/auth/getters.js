export function someGetter (/* state */) {
}
export const isAnonymous = ({ isAnonymous }) => isAnonymous
