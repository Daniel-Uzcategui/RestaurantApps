export const corporativo = ({ corporativo }) => corporativo
