export default function () {
  return {

    corporativo: []
  }
}
