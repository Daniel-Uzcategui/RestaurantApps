export default function () {
  return {
    payments: [
      {
        id: 0,
        invoice: 48578,
        order_id: 1,
        status: 'En Espera',
        typePayment: 'Efectivo',
        amount: 10
      }
    ]
  }
}
