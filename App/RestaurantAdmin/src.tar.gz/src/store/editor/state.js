export default function () {
  return {
    editor: [ ]
  }
}
