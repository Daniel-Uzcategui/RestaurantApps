
export const editor = ({ editor }) => editor
