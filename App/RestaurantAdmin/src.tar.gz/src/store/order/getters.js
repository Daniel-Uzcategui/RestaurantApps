export const orders = ({ orders }) => orders
// eslint-disable-next-line camelcase
export const typePayment_options = ({ typePayment_options }) => typePayment_options
export const dateRange = ({ dateRange }) => dateRange
