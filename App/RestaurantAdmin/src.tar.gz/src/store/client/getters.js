export const clients = ({ clients }) => clients
export const clients2 = ({ clients2 }) => clients2
export const idClientSel = ({ idClientSel }) => idClientSel
export const vendedor = ({ vendedor }) => vendedor
