export default function () {
  return {
    clients: [
      {
        id: 0,
        identification: '',
        name: '',
        lastname: '',
        email: '',
        birthdate: '',
        status: '',
        address: '',
        phone: ''
      }
    ]
  }
}
