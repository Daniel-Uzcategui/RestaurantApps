export default function () {
  return {
    localizations: [
      {
        id: 0,
        localizacion_sede: []
      }
    ],
    localZones: []
  }
}
