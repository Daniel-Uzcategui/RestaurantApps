export default function () {
  return {
    riders: [
    ]
  }
}
