export const configs = ({ configs }) => configs
export const version = ({ version }) => version
export const config = ({ config }) => config
export const configurations = ({ configurations }) => configurations
export const paymentServ = ({ paymentServ }) => paymentServ
export const chat = ({ chat }) => chat
export const menucfg = ({ menucfg }) => menucfg
export const rates = ({ rates }) => rates
