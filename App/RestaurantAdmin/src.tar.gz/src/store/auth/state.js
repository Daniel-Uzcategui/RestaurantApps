export default {
  isAuthenticated: false,
  isReady: false,
  uid: '',
  rol: null
}
